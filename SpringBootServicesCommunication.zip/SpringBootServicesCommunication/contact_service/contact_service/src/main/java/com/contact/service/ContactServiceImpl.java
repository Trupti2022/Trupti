package com.contact.service;

import com.contact.entity.Contact;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactServiceImpl  implements  ContactService {

    // fake list of contact
    List<Contact> list= List.of(
            new Contact(1L,"trupti@gmail.com","Trupti",1311L),
            new Contact(2L,"bishesh@gmail.com","Bishesh",1312L),
            new Contact(3L,"lusi@gmail.com","Lusi",1313L),
            new Contact(4L,"swati@gmail.com","Swati",1311L)
    );
    @Override
    public List<Contact> getContactsOfUser(Long userId) {
        return list.stream().filter(contact -> contact.getUserId().equals(userId)).collect(Collectors.toList());
    }
}
