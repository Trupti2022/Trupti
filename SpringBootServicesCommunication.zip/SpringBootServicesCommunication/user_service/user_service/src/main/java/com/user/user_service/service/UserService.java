package com.user.user_service.service;

import com.user.user_service.entity.User;

public interface UserService {

     User getUser(Long id);

}
