package EmployeeSpringCore;

public class Employee {
	String empId;
	String name,designation,salary;
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	public void display()
	{
		
		System.out.println("the empId is "+empId);
		System.out.println("the name is "+name);
		System.out.println("the email is "+designation);
		System.out.println("the name is "+salary);
		}

}
