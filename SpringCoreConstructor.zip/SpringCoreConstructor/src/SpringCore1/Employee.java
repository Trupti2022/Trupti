package SpringCore1;

public class Employee
{
private int empid;
private String name,address;
public Employee(int empid, String name, String address) {
	
	this.empid = empid;
	this.name = name;
	this.address = address;
}


 public Employee() { System.out.println("This is default constructor"); }

void display()
{
	System.out.println("The empid is :"+empid+"The name is :"+name+" The address is "+address);
}

}
